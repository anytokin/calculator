"""Let's do some numbers!"""
__version__ = "0.1.6"
from powerful_calculator.powerful_calculator  import *